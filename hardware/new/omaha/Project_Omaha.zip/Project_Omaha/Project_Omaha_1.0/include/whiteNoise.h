#ifndef _WHITE_NOISE_H_
#define _WHITE_NOISE_H_

#include "constants.h"
#include "F2806x_Device.h"
#include "F2806x_Prototypes.h"

void 	loadWhiteNoiseSamples(int startingSample, int length);

#endif
